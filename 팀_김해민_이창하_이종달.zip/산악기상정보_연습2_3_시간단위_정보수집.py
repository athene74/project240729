import threading
import requests
import json
import pandas as pd
import cx_Oracle
import time
from datetime import datetime
from matplotlib import font_manager,rc
# 한글 폰트
font_location = "C:\Windows\Fonts\malgun.ttf"
font_name = font_manager.FontProperties(fname=font_location).get_name()
rc('font',family=font_name)

access_key='SjZDkZeoRAdpLZ0/HQhz8jEPnoyfugEsOTfyRZJ456vvxVKHqR4DPd7T9pRBxiOnTCoCf2wMwcH5ypBMlVs5Iw=='

def get_request_url(base_date):
    url = 'http://apis.data.go.kr/1400377/mtweather/mountListSearch'
    params = {
        'ServiceKey': access_key,
        'numOfRows': 7,
        'pageNo': 3,
        '_type': 'json',
        'tm': base_date,  # Ensure base_date includes time (e.g., '2024-08-02 14:00')
        'localArea': 10
    }
    response = requests.get(url, params=params)
    return response.text

def preprocess_df(df):
    # API에서 받은 tm 데이터의 형식으로 변환
    df['date_time'] = pd.to_datetime(df['tm'], format='%Y-%m-%d %H:%M')

    # 필요한 열만 선택하여 새로운 데이터프레임 생성
    p_df = df[['date_time', 'obsname', 'hm10m', 'ts']]

    # 열 이름 변경
    p_df.columns = ['DATE_TIME', '산이름', '습도', '기온']

    return p_df

def preprocessed_df_to_oracle(df):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.37:1521/xe')
    cur = conn.cursor()

    sql_insert = '''
    INSERT INTO WEATHER (DATE_TIME, 산이름, 습도, 기온)
    VALUES (:DATE_TIME, :산이름, :습도, :기온)
    '''

    try:
        for _, row in df.iterrows():
            cur.execute(sql_insert, (
                row['DATE_TIME'],
                row['산이름'],
                row['습도'],
                row['기온']
            ))
        conn.commit()
    except cx_Oracle.DatabaseError as e:
        print(f"데이터베이스 오류: {e}")
    finally:
        cur.close()
        conn.close()

def weather_info_collector():
    # 현재 날짜와 시간을 'YYYYMMDDHHMM' 형식으로 설정
    base_date = datetime.now().strftime("%Y%m%d%H")
    raw_str_json = get_request_url(base_date)

    if raw_str_json:
        try:
            raw_json = json.loads(raw_str_json)
            print(json.dumps(raw_json, indent=4, ensure_ascii=False))  # API 응답 디버깅

            # JSON 응답의 구조를 확인합니다.
            if 'response' in raw_json:
                if 'body' in raw_json['response']:
                    if 'items' in raw_json['response']['body']:
                        if 'item' in raw_json['response']['body']['items']:
                            parsed_json = raw_json['response']['body']['items']['item']
                        else:
                            print("Error: 'item' not found in API response")
                            return
                    else:
                        print("Error: 'items' not found in API response")
                        return
                else:
                    print("Error: 'body' not found in API response")
                    return
            else:
                print("Error: 'response' not found in API response")
                return

            df = pd.DataFrame(parsed_json)

            # 데이터프레임 내용 확인
            print(df.head())

            df_preprocessed = preprocess_df(df)
            print(df_preprocessed)

            preprocessed_df_to_oracle(df_preprocessed)
        except json.JSONDecodeError as e:
            print(f"JSON 디코딩 오류: {e}")
        except (TypeError, KeyError) as e:
            print(f"JSON 파싱 오류: {e}")
        except cx_Oracle.DatabaseError as e:
            print(f"데이터베이스 오류: {e}")


def weather_info_scheduler():
    print('\n산악기상정보 수집기 스케줄러 동작\n')
    while True:
        weather_info_collector()
        print("수집완료 ")
        time.sleep(300) # 1시간 주기로 데이터 수집

print('< 산악기상정보 데이터수집 스케줄러 ver1.0 >')

def print_main_menu():
    print('\n1. 산악기상정보 예측 실시간 데이터 수집')
    print('2. 업데이트 예정')
    print('3. 스케줄러 종료')
    print('* 엔터: 메뉴 업데이트\n')
while True:
    print_main_menu()
    print('아래행에 메뉴입력: ', end='')
    selection = input()
    if selection == '':  continue
    else:                menu_num = int(selection)

    if(menu_num == 1):
        t = threading.Thread(target=weather_info_scheduler, daemon=True)
        t.start()
    elif(menu_num == 2):
        print('업데이트 예정중입니다.')
    elif(menu_num == 3):
        break
    elif (menu_num == 0):
        continue
