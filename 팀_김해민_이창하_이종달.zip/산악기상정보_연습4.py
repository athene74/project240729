import cx_Oracle
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib import font_manager,rc
# 한글 폰트
font_location = "C:\Windows\Fonts\malgun.ttf"
font_name = font_manager.FontProperties(fname=font_location).get_name()
rc('font',family=font_name)
def get_data_from_oracle():
    conn = cx_Oracle.connect('open_source/1111@192.168.0.37:1521/xe')
    query = "SELECT * FROM (SELECT * FROM weather ORDER BY DATE_TIME DESC)"
    df = pd.read_sql(query, con=conn)
    conn.close()
    return df

def update(frame):
    weather_data = get_data_from_oracle()

    # Clear previous data
    ax1.clear()
    ax2.clear()

    ax1.bar(weather_data['산이름'], weather_data['습도'], color=['blue', 'green', 'red', 'purple', 'orange'])
    ax1.set_xlabel('산이름')
    ax1.tick_params(axis='x', rotation=45)
    ax1.set_ylabel('습도')
    ax1.set_title('산별 습도')


    ax2.bar(weather_data['산이름'], weather_data['기온'], color=['blue', 'green', 'red', 'purple', 'orange'])
    ax2.set_xlabel('산이름')
    ax2.tick_params(axis='x', rotation=45)
    ax2.set_ylabel('기온')
    ax2.set_title('산별 기온')

# Setup plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 7))

# Initialize the animation
ani = FuncAnimation(fig, update, interval=5000)  # Update every 5000 milliseconds (5 seconds)

plt.tight_layout()
plt.show()