import cx_Oracle
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
from matplotlib import font_manager,rc
# 한글 폰트
font_location = "C:\Windows\Fonts\malgun.ttf"
font_name = font_manager.FontProperties(fname=font_location).get_name()
rc('font',family=font_name)
def get_data_from_oracle():
    conn = cx_Oracle.connect('open_source/1111@192.168.0.32:1521/xe')
    query = "SELECT * FROM (SELECT * FROM water_temperature order by RECORD_TIME desc) WHERE ROWNUM <= 10 order by RECORD_TIME"
    df = pd.read_sql(query, con=conn)
    conn.close()
    return df





def plot_realtime_data():
    plt.ion()
    fig, ax = plt.subplots()

    while True:
        df = get_data_from_oracle()
        ax.clear()
        df.set_index('RECORD_TIME', inplace=True)
        for beach in df.columns:
            plt.plot(df.index, df[beach], label=beach)
        plt.xlabel('시간')
        plt.ylabel('온도(섭씨)')
        plt.legend()
        plt.xticks(rotation=45)
        plt.draw()
        plt.pause(5)

plot_realtime_data()

