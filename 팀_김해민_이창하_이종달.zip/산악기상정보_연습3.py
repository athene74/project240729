import cx_Oracle
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
from matplotlib import font_manager,rc
# 한글 폰트
font_location = "C:\Windows\Fonts\malgun.ttf"
font_name = font_manager.FontProperties(fname=font_location).get_name()
rc('font',family=font_name)
def get_data_from_oracle():
    conn = cx_Oracle.connect('open_source/1111@192.168.0.37:1521/xe')
    query = "SELECT * FROM (SELECT * FROM weather ORDER BY DATE_TIME DESC)"
    df = pd.read_sql(query, con=conn)
    conn.close()
    return df

def plot_realtime_data():
    plt.ion()  # Interactive mode on
    fig, ax = plt.subplots()

    while True:
        df = get_data_from_oracle()
        ax.clear()
        sns.lineplot(x='DATE_TIME', y='기온', data=df, ax=ax, marker='o')
        ax.set(title='실시간 강원도 산간지역 온도', xlabel='시간', ylabel='온도')
        plt.xticks(rotation=45)
        plt.draw()
        plt.pause(5)
plot_realtime_data()


#     # Plot bar chart
#     ax2.bar(weather_data['산이름'], weather_data['기온'], color=['blue', 'green', 'red', 'purple', 'orange'])
#     ax2.set_xlabel('산이름')
#     ax2.set_ylabel('기온')
#     ax2.set_title('산별 기온')
#
# # Setup plot
# fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 7))
#
# # Initialize the animation
# ani = FuncAnimation(fig, update, interval=5000)  # Update every 5000 milliseconds (5 seconds)
#
# plt.tight_layout()
# plt.show()