import threading
import time
import pandas as pd
import requests
import ssl
import json
import cx_Oracle

access_key = '7GeamV1TjaVlOvyIwJ8LOJV1vxtH8zq3DXyceWzZni1v4bY1RRMi/pzRY4pUdGApc+xJIdumoKbC2D7pSMHBlA=='

def get_request_url(str_date,str_time,ed_date,ed_time,fit_num):

    url = 'http://apis.data.go.kr/B500001/rwis/waterQuality/list'
    count = 1
    data = []
    params = {
        'serviceKey': access_key,
        '_type': 'json',
        'stDt': str_date,
        'stTm': str_time,
        'edDt': ed_date,
        'edTm': ed_time,
        'sujCode': fit_num,
        'numOfRows': 100,
        'pageNo': '1'
    }

    response = requests.get(url, params=params, verify=False)
    raw_json = response.json()

    parsed_json = raw_json['response']['body']['items']['item']
    for item in parsed_json:
        occrrncDt = item['occrrncDt']

        try:
            parsed_date = pd.to_datetime(occrrncDt, format="%Y%m%d%H")
            formatted_date = parsed_date.strftime('%Y-%m-%d')
            formatted_time = parsed_date.strftime('%H시')
        except ValueError as e:
            continue
        try:
            fclty_nm = str(item['fcltyMngNm'])
            cl_val = float(item['clVal'])
            ph_val = float(item['phVal'])
            tb_val = float(item['tbVal'])
        except ValueError as e:
            continue

        data.append([
            formatted_date,
            formatted_time,
            fclty_nm,
            cl_val,
            ph_val,
            tb_val
        ])
        print(f'{count}건 데이터 수집중...')
        count = count + 1

    df = pd.DataFrame(data=data, columns=['발생일', '발생시간', '시설관리명', '잔류염소', 'pH', '탁도'])
    # df = df.set_index('발생일')

    return df


def input_simulator():
    fit_num = input('조회하려는 정수장 코드를 입력하세요.: ')
    str_date = input('조회시작일자를 입력하세요.(YYYY-MM-DD): ')
    str_time = input('조회시작시간을 입력하세요.(HH): ')
    ed_date = input('조회종료일자를 입력하세요.(YYYY-MM-DD): ')
    ed_time = input('조회종료시간을 입력하세요.(HH): ')
    return str_date, str_time, ed_date, ed_time, fit_num


def preprocessed_df_to_oracle(df):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.29:1521/xe')
    cur = conn.cursor()

    sql_insert = '''
    insert into
    filter(발생일,발생시간,시설관리명,잔류염소,pH,탁도)
    values(:발생일,:발생시간,:시설관리명,:잔류염소,:pH,:탁도)
    '''

    rows = df.to_dict(orient='records')  # DataFrame을 딕셔너리 리스트로 변환
    cur.executemany(sql_insert, rows)

    conn.commit()
    cur.close()
    conn.close()


def filt_info_collector():
    str_date = time.strftime("%Y%m%d")
    str_time = time.strftime("%H")
    ed_date = time.strftime("%Y%m%d")
    ed_time = time.strftime("%H")


    url = 'http://apis.data.go.kr/B500001/rwis/waterQuality/list'
    data = []
    params = {
        'serviceKey': access_key,
        '_type': 'json',
        'stDt': str_date,
        'stTm': str_time,
        'edDt': ed_date,
        'edTm': ed_time,
        'sujCode': fit_num,
        'numOfRows': 100,
        'pageNo': '1'
    }
    response = requests.get(url, params=params, verify=False)
    raw_json = response.json()

    parsed_json = raw_json['response']['body']['items']
    for key in parsed_json:
        occrrncDt = key['occrrncDt']

        parsed_date = pd.to_datetime(occrrncDt, format="%Y%m%d%H")
        formatted_date = parsed_date.strftime('%Y-%m-%d')
        formatted_time = parsed_date.strftime('%H시')

        fclty_nm = str(parsed_json['item']['fcltyMngNm'])
        cl_val = float(parsed_json['item']['clVal'])
        ph_val = float(parsed_json['item']['phVal'])
        tb_val = float(parsed_json['item']['tbVal'])

        data.append([
            formatted_date,
            formatted_time,
            fclty_nm,
            cl_val,
            ph_val,
            tb_val
        ])


    df = pd.DataFrame(data=data, columns=['발생일', '발생시간', '시설관리명', '잔류염소', 'pH', '탁도'])

    print(df)

    preprocessed_df_to_oracle(df)

#4번 실시간 수집기
def real_time_preprocessed_df_to_oracle(df):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.5:1521/xe')
    cur = conn.cursor()

    sql_insert = '''
    insert into
    filter(발생일,발생시간,시설관리명,잔류염소,pH,탁도)
    values(:발생일,:발생시간,:시설관리명,:잔류염소,:pH,:탁도)
    '''
    #특정행의 첫번째 값
    발생일 = df['발생일'].iloc[0]
    발생시간 = df['발생시간'].iloc[0]
    시설관리명 = df['시설관리명'].iloc[0]
    잔류염소 = df['잔류염소'].iloc[0]
    pH = df['pH'].iloc[0]
    탁도 = df['탁도'].iloc[0]

    cur.execute(sql_insert, (발생일,발생시간,시설관리명,잔류염소,pH,탁도))

    conn.commit()
    cur.close()
    conn.close()
def filt_info_scheduler():
    print('\n기상정보 수집기 스케줄러 동작\n')
    while True:
        filt_info_collector()
        print("수집완료")
        time.sleep(3600)




print('전국 정수장 데이터 수집기 시뮬레이션 프로그램 ver0.1')

def print_main_menu():
    print('\n1. 정수장 데이터 수집')
    print('2. 정수장 수질 조회및 저장')
    print('3. 데이터 오라클에 업로드')
    print('4. 정수장 수질정보 수집기 스케줄러 동작')
    print('5. 프로그램 종료')
    print('* 엔터: 메뉴 업데이트\n')

while True:
    print_main_menu()
    print('메뉴입력: ', end='')
    selection = input()
    if selection == '': continue
    else: menu_num = int(selection)

    if(menu_num == 1):
        str_date,str_time,ed_date,ed_time,fit_num = input_simulator()
        df = get_request_url(str_date,str_time,ed_date,ed_time,fit_num)
        print(df)

    elif(menu_num == 2):
        str_date,str_time,ed_date,ed_time,fit_num = input_simulator()
        title = input('저장하려는 데이터 제목을 입력하세요: ')
        df = get_request_url(str_date,str_time,ed_date,ed_time,fit_num)
        df.to_csv(f'{title}.csv', encoding='cp949')
        print(f'{title}이름으로 데이터를 출력했습니다.')

    elif(menu_num == 3):
        str_date, str_time, ed_date, ed_time, fit_num = input_simulator()
        df = get_request_url(str_date,str_time,ed_date,ed_time,fit_num)
        preprocessed_df_to_oracle(df)

    elif(menu_num == 4):
        str_date, str_time, ed_date, ed_time, fit_num = input_simulator()
        df = get_request_url(str_date, str_time, ed_date, ed_time, fit_num)

        real_time_preprocessed_df_to_oracle(df)
    elif(menu_num == 5):
        break
    elif (menu_num == 0):
        continue