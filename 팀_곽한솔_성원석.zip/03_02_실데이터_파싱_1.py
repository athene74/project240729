import cx_Oracle
import requests

access_key = '74694d524a6c6f653637674a65474f'

def get_request_url():
    base_url1 = 'http://openapi.seoul.go.kr:8088'
    type = 'xml'
    base_url2 = 'citydata_ppltn'
    start_row = 1
    end_row = 5
    location = '강남역'

    url = f'{base_url1}/{access_key}/{type}/{base_url2}/{start_row}/{end_row}/{location}'

    response = requests.get(url)
    return response.text

def select_no_from_oracle(no):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.22:1521/xe')
    cur = conn.cursor()

    sql_select = '''
    select AREA_NM
    from seoul_location
    where no = :no
    '''

    cur.execute(sql_select, no)
    conn.commit()
    cur.close()
    conn.close()

raw_str_xml = get_request_url()
print(raw_str_xml)
print(type(raw_str_xml))

