import cx_Oracle
import requests
import pandas as pd
import time
from xml.etree.ElementTree import fromstring

access_key = '74694d524a6c6f653637674a65474f'

def get_request_url(no):

    base_url1 = 'http://openapi.seoul.go.kr:8088'
    type = 'xml'
    base_url2 = 'citydata_ppltn'
    start_row = 1
    end_row = 5
    location = select_from_oracle(no)

    url = f'{base_url1}/{access_key}/{type}/{base_url2}/{start_row}/{end_row}/{location[0]}'
    response = requests.get(url)
    xml_root = fromstring(response.text)

    if xml_root:
        data.append([
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_TIME').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('AREA_NM').text,
            location[1],
            xml_root.find('SeoulRtd.citydata_ppltn').find('AREA_CONGEST_LVL').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('AREA_PPLTN_MIN').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('AREA_PPLTN_MAX').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('MALE_PPLTN_RATE').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('FEMALE_PPLTN_RATE').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_0').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_10').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_20').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_30').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_40').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_50').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_60').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('PPLTN_RATE_70').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('RESNT_PPLTN_RATE').text,
            xml_root.find('SeoulRtd.citydata_ppltn').find('NON_RESNT_PPLTN_RATE').text
        ])
    return data

def select_from_oracle(no):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.22:1521/xe')
    cur = conn.cursor()

    sql_select = '''
    select AREA_NM, CATEGORY
    from seoul_location
    where no = :no
    '''

    cur.execute(sql_select, [no])
    conn.commit()
    result = cur.fetchone()
    cur.close()
    conn.close()
    return result

def insert_to_oracle(df):
    conn = cx_Oracle.connect('open_source/1111@192.168.0.22:1521/xe')
    cur = conn.cursor()

    sql_insert = '''
    insert into
    seoul_population(업데이트시간, 장소, 지역구분, 혼잡도, 실시간인구지표최소값, 실시간인구지표최대값, 남성인구비율, 여성인구비율, 인구비율_0, 인구비율_10, 인구비율_20, 인구비율_30, 인구비율_40, 인구비율_50, 인구비율_60, 인구비율_70, 상주인구비율, 비상주인구비율)
    values(:업데이트시간, :장소, :지역구분, :혼잡도, :실시간인구지표최소값, :실시간인구지표최대값, :남성인구비율, :여성인구비율, :인구비율_0, :인구비율_10, :인구비율_20, :인구비율_30, :인구비율_40, :인구비율_50, :인구비율_60, :인구비율_70, :상주인구비율, :비상주인구비율) 
    '''

    for i in range(0, 115):
        업데이트시간 = df['업데이트시간'].iloc[i]
        장소 = df['장소'].iloc[i]
        지역구분 = df['지역구분'].iloc[i]
        혼잡도 = df['혼잡도'].iloc[i]
        실시간인구지표최소값 = df['실시간인구지표최소값'].iloc[i]
        실시간인구지표최대값 = df['실시간인구지표최대값'].iloc[i]
        남성인구비율 = df['남성인구비율'].iloc[i]
        여성인구비율 = df['여성인구비율'].iloc[i]
        인구비율_0 = df['인구비율_0'].iloc[i]
        인구비율_10 = df['인구비율_10'].iloc[i]
        인구비율_20 = df['인구비율_20'].iloc[i]
        인구비율_30 = df['인구비율_30'].iloc[i]
        인구비율_40 = df['인구비율_40'].iloc[i]
        인구비율_50 = df['인구비율_50'].iloc[i]
        인구비율_60 = df['인구비율_60'].iloc[i]
        인구비율_70 = df['인구비율_70'].iloc[i]
        상주인구비율 = df['상주인구비율'].iloc[i]
        비상주인구비율 = df['상주인구비율'].iloc[i]

        cur.execute(sql_insert, (업데이트시간, 장소, 지역구분, 혼잡도, 실시간인구지표최소값, 실시간인구지표최대값, 남성인구비율, 여성인구비율, 인구비율_0, 인구비율_10, 인구비율_20, 인구비율_30, 인구비율_40, 인구비율_50, 인구비율_60, 인구비율_70, 상주인구비율, 비상주인구비율))
        conn.commit()
    cur.close()
    conn.close()

while True:
    data = []
    print('최신 데이터 수집을 시작합니다.')
    for i in range(1, 116):
        get_request_url(i)
        print(f'{i}번째 데이터 수집완료')

    df = pd.DataFrame(data, columns=['업데이트시간', '장소', '지역구분', '혼잡도', '실시간인구지표최소값', '실시간인구지표최대값', '남성인구비율', '여성인구비율',
                                     '인구비율_0', '인구비율_10', '인구비율_20', '인구비율_30', '인구비율_40', '인구비율_50', '인구비율_60',
                                     '인구비율_70', '상주인구비율', '비상주인구비율'])

    insert_to_oracle(df)
    print('현재시간: ', time.localtime())
    time.sleep(60)
    print('데이터 수집완료 후 1분이 지났습니다')
    time.sleep(60)
    print('데이터 수집완료 후 2분이 지났습니다')
    time.sleep(60)
    print('데이터 수집완료 후 3분이 지났습니다')
    time.sleep(60)
    print('데이터 수집완료 후 4분이 지났습니다')
    time.sleep(60)
    print('데이터 수집완료 후 5분이 지났습니다')