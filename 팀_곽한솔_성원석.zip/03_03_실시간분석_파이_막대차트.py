import cx_Oracle
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib import font_manager, rc

# 한글 폰트
font_location = "C:\Windows\Fonts\malgun.ttf"
font_name = font_manager.FontProperties(fname=font_location).get_name()
rc('font',family=font_name)

def fetch_population_data():
    conn = cx_Oracle.connect('open_source/1111@192.168.0.22:1521/xe')
    query = 'select * from seoul_population'
    df = pd.read_sql(query, con = conn)
    conn.close()
    return df

def update(frame):
    population_data = fetch_population_data()

    ax1.clear()

    ax1.bar(population_data['실시간인구지표최대값'], labels = population_data['지역구분'], color=['blue', 'green', 'red', 'purple', 'orange'])
    ax1.set_xlabel('지역구분')
    ax1.set_ylabel('인구수')
    ax1.set_title('지역구분 별 인구수')

ani = FuncAnimation(update, interval = 5000)

plt.tight_layout()
plt.show()